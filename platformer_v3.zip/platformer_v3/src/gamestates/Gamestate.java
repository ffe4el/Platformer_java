package gamestates;

// 메뉴 레이아웃 글자
public enum Gamestate {
	
	PLAYING, MENU, OPTIONS, QUIT;
	
	public static Gamestate state = MENU;

}
